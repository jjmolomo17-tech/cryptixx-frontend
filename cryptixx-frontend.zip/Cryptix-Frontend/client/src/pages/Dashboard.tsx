import React from "react";
import { Sidebar } from "@/components/layout/Sidebar";
import { Header } from "@/components/layout/Header";
import { MetricCard } from "@/components/ui/MetricCard";
import { ChartVisual } from "@/components/ui/ChartVisual";
import { TransactionTable } from "@/components/ui/TransactionTable";
import { metricData } from "@/data/mockData";
import { Bitcoin, Download } from "lucide-react";

export default function Dashboard() {
  return (
    <div className="min-h-screen bg-background text-foreground font-sans selection:bg-primary/20 selection:text-primary">
      <Sidebar />
      
      <div className="md:ml-64 transition-all duration-300">
        <Header />
        
        <main className="p-6 md:p-10 space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-700">
          
          {/* Welcome Section */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold tracking-tight text-white mb-2">
                Dashboard Overview
              </h1>
              <p className="text-muted-foreground">
                Welcome back, Alex. Here's what's happening with your portfolio today.
              </p>
            </div>
            
            <button className="flex items-center gap-2 bg-primary text-primary-foreground hover:bg-primary/90 px-5 py-2.5 rounded-xl font-medium transition-all shadow-lg shadow-primary/20 active:scale-95">
              <Download size={18} />
              Export Report
            </button>
          </div>

          {/* Metrics Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {metricData.map((data) => (
              <MetricCard key={data.title} {...data} />
            ))}
          </div>

          {/* Main Chart Section */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Chart Container - Takes up 2/3 columns on large screens */}
            <div className="lg:col-span-2 glass-panel rounded-3xl p-6 md:p-8">
              <div className="flex items-center justify-between mb-8">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-orange-500/10 flex items-center justify-center text-orange-500">
                    <Bitcoin size={28} />
                  </div>
                  <div>
                    <h2 className="text-xl font-bold text-white">Bitcoin Price</h2>
                    <p className="text-sm text-muted-foreground font-mono">BTC/USD</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  {['1H', '1D', '1W', '1M', '1Y'].map((time) => (
                    <button 
                      key={time}
                      className={`px-3 py-1 text-xs font-medium rounded-lg transition-colors ${
                        time === '1W' 
                          ? 'bg-secondary text-white' 
                          : 'text-muted-foreground hover:bg-secondary/50 hover:text-white'
                      }`}
                    >
                      {time}
                    </button>
                  ))}
                </div>
              </div>
              
              {/* The Static Tailwind Chart */}
              <div className="h-[300px] w-full">
                <ChartVisual />
              </div>
            </div>

            {/* Side Panel / Quick Stats - Takes up 1/3 column */}
            <div className="glass-panel rounded-3xl p-6 md:p-8 flex flex-col justify-between">
               <div>
                 <h3 className="text-lg font-bold text-white mb-6">Portfolio Distribution</h3>
                 <div className="space-y-6">
                   {[
                     { name: 'Bitcoin', pct: 45, color: 'bg-orange-500' },
                     { name: 'Ethereum', pct: 30, color: 'bg-blue-500' },
                     { name: 'Solana', pct: 15, color: 'bg-purple-500' },
                     { name: 'USDT', pct: 10, color: 'bg-green-500' }
                   ].map((coin) => (
                     <div key={coin.name}>
                       <div className="flex justify-between text-sm mb-2">
                         <span className="font-medium">{coin.name}</span>
                         <span className="text-muted-foreground">{coin.pct}%</span>
                       </div>
                       <div className="h-2 w-full bg-secondary rounded-full overflow-hidden">
                         <div className={`h-full ${coin.color}`} style={{ width: `${coin.pct}%` }}></div>
                       </div>
                     </div>
                   ))}
                 </div>
               </div>
               
               <div className="mt-8 p-4 rounded-2xl bg-gradient-to-br from-primary/20 to-transparent border border-primary/20">
                 <p className="text-sm text-primary font-medium mb-1">Portfolio Advice</p>
                 <p className="text-xs text-muted-foreground leading-relaxed">
                   Consider rebalancing your portfolio. Bitcoin dominance has increased by 5% in the last 24 hours.
                 </p>
               </div>
            </div>
          </div>

          {/* Transactions Table Section */}
          <div className="glass-panel rounded-3xl p-6 md:p-8">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-white">Recent Transactions</h2>
              <button className="text-sm text-primary hover:text-primary/80 transition-colors">
                View All
              </button>
            </div>
            <TransactionTable />
          </div>

        </main>
      </div>
    </div>
  );
}
