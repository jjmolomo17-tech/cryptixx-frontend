
import { 
  LayoutDashboard, 
  Wallet, 
  ArrowRightLeft, 
  LineChart, 
  Settings, 
  LogOut,
  TrendingUp,
  TrendingDown,
  DollarSign,
  Bitcoin,
  Activity
} from "lucide-react";

export interface NavItem {
  label: string;
  icon: any;
  active?: boolean;
}

export const navItems: NavItem[] = [
  { label: "Dashboard", icon: LayoutDashboard, active: true },
  { label: "Wallet", icon: Wallet },
  { label: "Transactions", icon: ArrowRightLeft },
  { label: "Analytics", icon: LineChart },
  { label: "Settings", icon: Settings },
];

export interface MetricData {
  title: string;
  value: string;
  change: string;
  isPositive: boolean;
  icon: any;
}

export const metricData: MetricData[] = [
  {
    title: "Total Profit",
    value: "$12,345.67",
    change: "+15.2%",
    isPositive: true,
    icon: DollarSign,
  },
  {
    title: "Market Cap",
    value: "$48.2B",
    change: "+2.4%",
    isPositive: true,
    icon: Activity,
  },
  {
    title: "Daily Volume",
    value: "$1.2B",
    change: "-0.8%",
    isPositive: false,
    icon: TrendingUp,
  },
];

export interface Transaction {
  id: string;
  type: "Buy" | "Sell" | "Transfer";
  asset: string;
  amount: string;
  price: string;
  date: string;
  status: "Completed" | "Pending" | "Failed";
}

export const transactionData: Transaction[] = [
  {
    id: "TX-1001",
    type: "Buy",
    asset: "Bitcoin",
    amount: "0.45 BTC",
    price: "$42,150.00",
    date: "2025-05-12",
    status: "Completed",
  },
  {
    id: "TX-1002",
    type: "Sell",
    asset: "Ethereum",
    amount: "2.5 ETH",
    price: "$3,200.00",
    date: "2025-05-11",
    status: "Completed",
  },
  {
    id: "TX-1003",
    type: "Transfer",
    asset: "USDT",
    amount: "500.00 USDT",
    price: "$1.00",
    date: "2025-05-10",
    status: "Pending",
  },
  {
    id: "TX-1004",
    type: "Buy",
    asset: "Solana",
    amount: "150 SOL",
    price: "$145.20",
    date: "2025-05-09",
    status: "Completed",
  },
  {
    id: "TX-1005",
    type: "Sell",
    asset: "Bitcoin",
    amount: "0.1 BTC",
    price: "$41,800.00",
    date: "2025-05-08",
    status: "Completed",
  },
];

// Static data points for the custom chart (normalized 0-100 for easy SVG plotting)
export const chartDataPoints = [
  20, 45, 30, 55, 45, 65, 50, 75, 60, 90, 85, 95, 80, 70, 85, 100
];
