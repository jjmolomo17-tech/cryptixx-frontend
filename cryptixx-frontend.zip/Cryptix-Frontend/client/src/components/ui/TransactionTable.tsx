import React from "react";
import { transactionData } from "@/data/mockData";
import { Badge } from "@/components/ui/badge";
import { ArrowUpRight, ArrowDownRight, RefreshCcw } from "lucide-react";

export function TransactionTable() {
  return (
    <div className="w-full overflow-x-auto" data-testid="table-transactions">
      <table className="w-full text-left text-sm">
        <thead>
          <tr className="border-b border-border/50 text-muted-foreground">
            <th className="pb-4 font-medium pl-4">Transaction ID</th>
            <th className="pb-4 font-medium">Type</th>
            <th className="pb-4 font-medium">Asset</th>
            <th className="pb-4 font-medium">Amount</th>
            <th className="pb-4 font-medium">Price</th>
            <th className="pb-4 font-medium">Date</th>
            <th className="pb-4 font-medium pr-4 text-right">Status</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-border/30">
          {transactionData.map((tx) => (
            <tr 
              key={tx.id} 
              className="group hover:bg-white/5 transition-colors"
              data-testid={`row-transaction-${tx.id}`}
            >
              <td className="py-4 pl-4 font-mono text-muted-foreground group-hover:text-foreground transition-colors">
                {tx.id}
              </td>
              <td className="py-4">
                <div className="flex items-center gap-2">
                  <div className={`p-1.5 rounded-full ${
                    tx.type === "Buy" ? "bg-primary/20 text-primary" :
                    tx.type === "Sell" ? "bg-destructive/20 text-destructive" :
                    "bg-blue-500/20 text-blue-500"
                  }`}>
                    {tx.type === "Buy" && <ArrowDownRight size={14} />}
                    {tx.type === "Sell" && <ArrowUpRight size={14} />}
                    {tx.type === "Transfer" && <RefreshCcw size={14} />}
                  </div>
                  <span className="font-medium">{tx.type}</span>
                </div>
              </td>
              <td className="py-4 font-medium text-white">{tx.asset}</td>
              <td className="py-4 font-mono">{tx.amount}</td>
              <td className="py-4 font-mono text-muted-foreground">{tx.price}</td>
              <td className="py-4 text-muted-foreground">{tx.date}</td>
              <td className="py-4 pr-4 text-right">
                <Badge variant="outline" className={`
                  ${tx.status === "Completed" ? "border-primary/50 text-primary bg-primary/5" : ""}
                  ${tx.status === "Pending" ? "border-yellow-500/50 text-yellow-500 bg-yellow-500/5" : ""}
                  ${tx.status === "Failed" ? "border-destructive/50 text-destructive bg-destructive/5" : ""}
                `}>
                  {tx.status}
                </Badge>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
