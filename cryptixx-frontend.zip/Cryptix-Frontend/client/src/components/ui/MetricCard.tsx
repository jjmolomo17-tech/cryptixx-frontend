import React from "react";
import { cn } from "@/lib/utils";
import { MetricData } from "@/data/mockData";
import { ArrowUpRight, ArrowDownRight } from "lucide-react";

interface MetricCardProps extends MetricData {
  className?: string;
}

export function MetricCard({ title, value, change, isPositive, icon: Icon, className }: MetricCardProps) {
  return (
    <div 
      className={cn(
        "glass-panel rounded-2xl p-6 relative overflow-hidden group hover:border-primary/20 transition-all duration-300",
        className
      )}
      data-testid={`card-metric-${title}`}
    >
      <div className="relative z-10 flex flex-col h-full justify-between">
        <div className="flex justify-between items-start mb-4">
          <div className="p-2.5 rounded-xl bg-secondary/50 text-muted-foreground group-hover:text-primary group-hover:bg-primary/10 transition-colors">
            <Icon size={22} />
          </div>
          <div 
            className={cn(
              "flex items-center gap-1 text-xs font-semibold px-2 py-1 rounded-full border",
              isPositive 
                ? "text-primary bg-primary/10 border-primary/20" 
                : "text-destructive bg-destructive/10 border-destructive/20"
            )}
          >
            {isPositive ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}
            {change}
          </div>
        </div>
        
        <div>
          <p className="text-sm text-muted-foreground font-medium mb-1">{title}</p>
          <h3 className="text-2xl font-bold text-white tracking-tight">{value}</h3>
        </div>
      </div>

      {/* Decorative Background Glow */}
      <div 
        className={cn(
          "absolute -right-6 -bottom-6 w-24 h-24 rounded-full blur-3xl opacity-20 group-hover:opacity-30 transition-opacity",
          isPositive ? "bg-primary" : "bg-destructive"
        )} 
      />
    </div>
  );
}
