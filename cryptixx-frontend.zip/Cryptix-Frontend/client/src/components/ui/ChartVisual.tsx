import React from "react";
import { chartDataPoints } from "@/data/mockData";

export function ChartVisual() {
  // Generate SVG path command from data points
  // We'll normalize the width to 1000 and height to 300
  const width = 1000;
  const height = 300;
  const points = chartDataPoints;
  
  const stepX = width / (points.length - 1);
  
  // Create the line path
  let pathD = `M 0 ${height - (points[0] / 100) * height}`;
  
  // Using cubic bezier curves for smoothness
  for (let i = 0; i < points.length - 1; i++) {
    const x0 = i * stepX;
    const y0 = height - (points[i] / 100) * height;
    const x1 = (i + 1) * stepX;
    const y1 = height - (points[i + 1] / 100) * height;
    
    // Control points for smooth curve
    const cp1x = x0 + stepX / 2;
    const cp1y = y0;
    const cp2x = x1 - stepX / 2;
    const cp2y = y1;
    
    pathD += ` C ${cp1x} ${cp1y}, ${cp2x} ${cp2y}, ${x1} ${y1}`;
  }

  // Create the area fill path (closes the loop at the bottom)
  const areaPathD = `${pathD} L ${width} ${height} L 0 ${height} Z`;

  return (
    <div className="w-full h-full relative" data-testid="chart-btc-visual">
      <svg 
        viewBox={`0 0 ${width} ${height}`} 
        className="w-full h-full overflow-visible"
        preserveAspectRatio="none"
      >
        <defs>
          <linearGradient id="chartGradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="hsl(var(--primary))" stopOpacity="0.3" />
            <stop offset="100%" stopColor="hsl(var(--primary))" stopOpacity="0" />
          </linearGradient>
        </defs>

        {/* Grid Lines (Vertical) */}
        {[...Array(6)].map((_, i) => (
          <line 
            key={`v-${i}`}
            x1={i * (width / 5)} 
            y1="0" 
            x2={i * (width / 5)} 
            y2={height} 
            stroke="hsl(var(--border))" 
            strokeWidth="1" 
            strokeDasharray="4 4"
            className="opacity-30"
          />
        ))}

        {/* Grid Lines (Horizontal) */}
        {[...Array(4)].map((_, i) => (
          <line 
            key={`h-${i}`}
            x1="0" 
            y1={i * (height / 3)} 
            x2={width} 
            y2={i * (height / 3)} 
            stroke="hsl(var(--border))" 
            strokeWidth="1" 
            strokeDasharray="4 4"
            className="opacity-30"
          />
        ))}

        {/* Area Fill */}
        <path 
          d={areaPathD} 
          fill="url(#chartGradient)" 
          className="transition-all duration-1000 ease-out"
        />

        {/* Line Stroke */}
        <path 
          d={pathD} 
          fill="none" 
          stroke="hsl(var(--primary))" 
          strokeWidth="3" 
          strokeLinecap="round"
          strokeLinejoin="round"
          className="drop-shadow-[0_0_10px_rgba(34,197,94,0.5)]"
        />

        {/* Data Points (Dots) */}
        {points.map((point, i) => (
          <circle
            key={i}
            cx={i * stepX}
            cy={height - (point / 100) * height}
            r="4"
            fill="hsl(var(--background))"
            stroke="hsl(var(--primary))"
            strokeWidth="2"
            className="hover:scale-150 transition-transform cursor-pointer"
          >
            <title>{`Value: ${point}`}</title>
          </circle>
        ))}
      </svg>
      
      {/* Tooltip Overlay (Static simulation) */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 bg-card border border-border px-3 py-1.5 rounded-lg shadow-xl text-xs font-mono pointer-events-none animate-pulse">
        <span className="text-muted-foreground">Current:</span> <span className="text-primary font-bold">$42,150.00</span>
      </div>
    </div>
  );
}
