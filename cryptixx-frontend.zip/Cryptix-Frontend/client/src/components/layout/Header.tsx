import React from "react";
import { Search, Bell, User } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export function Header() {
  return (
    <header className="h-20 border-b border-border/40 bg-background/80 backdrop-blur-sm sticky top-0 z-40 px-6 md:px-10 flex items-center justify-between">
      {/* Mobile Menu Trigger (Hidden on Desktop) */}
      <div className="md:hidden">
        {/* Placeholder for hamburger menu if needed later */}
        <span className="font-bold text-lg">CryptX</span>
      </div>

      {/* Search Bar */}
      <div className="hidden md:flex items-center flex-1 max-w-md">
        <div className="relative w-full group">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground group-focus-within:text-primary transition-colors" size={18} />
          <input
            type="text"
            placeholder="Search assets, transactions..."
            className="w-full bg-secondary/50 border border-transparent focus:border-primary/50 focus:bg-secondary text-sm rounded-xl py-2.5 pl-10 pr-4 outline-none transition-all duration-300 placeholder:text-muted-foreground/70"
            data-testid="input-search"
          />
        </div>
      </div>

      {/* Right Actions */}
      <div className="flex items-center gap-4 md:gap-6">
        <button 
          className="relative p-2 text-muted-foreground hover:text-white transition-colors rounded-full hover:bg-white/5"
          data-testid="button-notifications"
        >
          <Bell size={20} />
          <span className="absolute top-2 right-2 w-2 h-2 bg-primary rounded-full ring-2 ring-background"></span>
        </button>

        <div className="flex items-center gap-3 pl-4 border-l border-border/50">
          <div className="text-right hidden md:block">
            <p className="text-sm font-medium text-white">Alex Morgan</p>
            <p className="text-xs text-muted-foreground">Premium User</p>
          </div>
          <Avatar className="h-10 w-10 border-2 border-border cursor-pointer hover:border-primary transition-colors">
            <AvatarImage src="https://github.com/shadcn.png" />
            <AvatarFallback>AM</AvatarFallback>
          </Avatar>
        </div>
      </div>
    </header>
  );
}
